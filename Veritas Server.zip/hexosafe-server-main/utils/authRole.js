export const authRole = {
  EMPLOYEE: "employee",
  ORGINAZATION: "orginazation",
};
